# LAPORAN TUGAS: Project 8. Enhancing IoT Security of IoT Web Applications

* **Nama Mahasiswa**: Muhammad Ketsar Ali Abi Wahid
* **NIM**: 230401070204
* **Mata Kuliah**: Internet of Things (IoT)
* **Dosen**: Prof. Jong-Dae Park
* **Institusi**: Universitas Siber Asia (UNSIA)

---

## A. Analisis Folder & Solusi Masalah ("Bermasalah" Fix)

Sebelumnya terdapat dua folder (`src` dan `JAWABAN`). Folder **`JAWABAN`** adalah pilihan terbaik dan paling siap untuk diserahkan karena:
1. **Konfigurasi Domain Remote**: Sudah disesuaikan untuk domain remote server Anda (`m70204.belajarhub.id`) dengan `DEBUG = False`, `ALLOWED_HOSTS`, dan `CSRF_TRUSTED_ORIGINS` yang tepat. Sedangkan `src` masih menggunakan template default (`yourdomain.belajarhub.id` dan `DEBUG = True`).
2. **CORS Headers**: Folder `JAWABAN` memiliki konfigurasi `django-cors-headers` yang krusial untuk menerima data dari client luar (seperti ESP8266/NodeMCU Anda).
3. **UI/Aesthetics**: Tampilan visual dashboard data dan gauge di `JAWABAN` jauh lebih rapi, modern, dan profesional dibandingkan tabel polos bawaan `src`.

### Perbaikan yang Telah Dilakukan:
* **Mengatasi Database Kosong**: Folder `JAWABAN` sebelumnya tidak memiliki file database `db.sqlite3`. Kami telah memindahkan database dari `src` yang sudah berisi migrasi database lengkap serta akun superuser bernama **`ketsar`**.
* **Melengkapi File Boilerplate**: Menyalin file `asgi.py`, `wsgi.py`, `apps.py`, `tests.py`, dan folder `migrations/` yang sempat hilang dari folder `JAWABAN`.
* **Solusi Bug Logout Django 5.x**: Pada Django 5.0+, `LogoutView` bawaan memblokir request bertipe **GET** (seperti link `<a>`) dan memicu error `Method Not Allowed (405)`. Kami membuat view kustom `logout_view` di `iot/views.py` yang memproses logout dengan aman dan mengarahkan pengguna kembali ke halaman login, sehingga navigasi web berjalan mulus.
* **Solusi Bug JavaScript Gauge**: Di file `sensor_gauge.html`, jika data sensor di database kosong, variabel JavaScript `latest` akan bernilai kosong dan memicu crash syntax error. Kami menambahkan blok pengaman `{% if latest %}` sebagai fallback.
* **Integrasi Link Navigasi**: Kami menambahkan tombol navigasi yang mempertemukan halaman Tabel Data, halaman Visualisasi Gauge, dan tombol **Logout** di pojok kanan atas agar pengguna tidak perlu mengetikkan URL manual.

---

## B. Jawaban Tugas (Task 1)

### Task 1: Cara Mengaktifkan Fitur Login dan Membatasi Views di Django

Untuk mengamankan web IoT agar data hanya bisa diakses oleh user yang sudah masuk (authenticated), kita menggunakan sistem autentikasi bawaan Django (`django.contrib.auth`).

1. **Proteksi Menggunakan Decorator `@login_required`**:
   Kita menerapkan decorator `@login_required` pada view fungsi yang menampilkan data sensitif (yaitu `device_data_view` dan `sensor_gauge_view`). Ketika pengguna yang belum login mencoba mengakses halaman tersebut, Django secara otomatis akan menghentikan akses mereka dan mengarahkannya (redirect) ke halaman login.

2. **Pengecualian REST API Endpoint**:
   Endpoint POST API `receive_sensor_data` (digunakan oleh hardware ESP8266 untuk mengirim data sensor) **tidak diberi proteksi** `@login_required`. Hal ini karena mikrokontroler bersifat *headless* (tidak memiliki web browser untuk login via form session). Sebagai gantinya, keamanan API ini dilindungi menggunakan metode **API Key Validation** (`is_valid_apikey`) yang dikirimkan dalam payload JSON.

---

## C. Detail Modifikasi File (Submission Requirements)

Berikut adalah ringkasan kode yang dimodifikasi untuk mengaktifkan fitur ini:

### 1. File `settings.py` (Konfigurasi Autentikasi & URL)
Kami mendaftarkan aplikasi sistem autentikasi bawaan Django dan menentukan jalur pengalihan halaman login/logout.

```python
# settings.py

# 1. Pastikan aplikasi auth & session aktif (Default Django)
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',         # Sistem Autentikasi
    'django.contrib.contenttypes',
    'django.contrib.sessions',     # Sistem Session
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'corsheaders',
    'iot',
]

# 2. Pastikan Middleware Autentikasi terpasang
MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware', # Session
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware', # Auth
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# 3. Pengaturan Redirect Halaman Login & Logout
LOGIN_URL = '/login/'                     # Alamat jika user belum login dan terlempar proteksi
LOGIN_REDIRECT_URL = '/device/device01/'  # Tujuan redirect setelah berhasil login
LOGOUT_REDIRECT_URL = '/login/'           # Tujuan redirect setelah logout
```

### 2. File `urls.py` (Routing Login, Logout, & Root Redirect)
Kami mengatur URL `/login/` ke form login bawaan Django, `/logout/` ke view kustom, serta root URL `/` agar dinamis mengalihkan pengguna ke dashboard utama (sehingga kompatibel dengan subpath `/django/` di server remote).

```python
# myproject/urls.py
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from iot import views as iot_views  # Mengimpor view dari aplikasi iot

urlpatterns = [
    path('admin/', admin.site.urls),
    # Mengarahkan login ke template login.html custom kita
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    # Mengarahkan logout ke fungsi kustom di views.py untuk mendukung GET request
    path('logout/', iot_views.logout_view, name='logout'),
    # Mengarahkan root URL (/) ke view dinamis root_redirect
    path('', iot_views.root_redirect, name='root_redirect'),
    path('', include('iot.urls')),
]
```

### 3. File `iot/views.py` (Proteksi Halaman & Kustom Logout)
Membatasi akses ke dashboard data dan gauge menggunakan `@login_required` serta mendefinisikan fungsi logout kustom.

```python
# iot/views.py
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.shortcuts import render, redirect

# Proteksi view Tabel Data
@login_required
def device_data_view(request, device_id):
    data = SensorData.objects.filter(device_id=device_id).order_by('-timestamp')[:100]
    return render(request, 'sensor_data.html', {'device_id': device_id, 'data': data})

# Proteksi view Gauge Visual
@login_required
def sensor_gauge_view(request, device_id):
    latest = SensorData.objects.filter(device_id=device_id).order_by('-timestamp').first()
    # ... logic ticks ...
    return render(request, 'sensor_gauge.html', {
        'device_id': device_id,
        'latest': latest,
        # ...
    })

# Fungsi logout kustom agar kompatibel dengan GET request link navigasi
def logout_view(request):
    logout(request)
    return redirect('login')

# Mengalihkan root URL secara dinamis menggunakan reverse routing agar mendukung subpath /django/ di server remote
def root_redirect(request):
    return redirect('device_data_view', device_id='device01')
```

### 4. File Template `login.html` (Form Login Pengguna)
Template ini menyajikan formulir yang memproses input username dan password pengguna dengan aman menggunakan enkripsi session.

```html
<!-- iot/templates/login.html -->
<form method="post">
    <!-- CSRF Token wajib ada demi keamanan dari serangan Cross-Site Request Forgery -->
    {% csrf_token %}
    
    <div class="form-group">
        <label for="id_username">Username</label>
        <!-- form.username merender tag <input type="text"> bawaan Django secara otomatis -->
        {{ form.username }}
    </div>
    
    <div class="form-group">
        <label for="id_password">Password</label>
        <!-- form.password merender tag <input type="password"> bawaan Django secara otomatis -->
        {{ form.password }}
    </div>
    
    <button type="submit">Masuk</button>
</form>
```

---

## D. Cara Menjalankan Project

1. Pastikan Anda berada di direktori project `JAWABAN`.
2. Aktifkan virtual environment Anda (`venv`).
3. Jalankan server lokal:
   ```bash
   python manage.py runserver
   ```
4. Buka browser dan akses alamat utama web:
   `http://127.0.0.1:8000/` (Root path akan otomatis ter-redirect dengan aman ke `/device/device01/`, yang kemudian mengarah ke halaman login `/login/` karena belum terautentikasi).
5. Masukkan kredensial default yang sudah terdaftar di database:
   * **Username**: `m70204`
   * **Password**: `m70204*01`
6. Setelah berhasil login, Anda akan langsung diarahkan kembali ke dashboard data sensor `device01`.
